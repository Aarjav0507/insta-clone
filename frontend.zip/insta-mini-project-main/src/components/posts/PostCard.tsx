import { useState } from 'react';
import { Link } from 'react-router-dom';
import { Heart, MessageCircle, Send, Bookmark } from 'lucide-react';
import { Post } from '@/types';
import { useAuth } from '@/context/AuthContext';
import { getUserById, getPostsFromStorage, savePostsToStorage } from '@/data/mockData';
import { Button } from '@/components/ui/button';
import { cn } from '@/lib/utils';
import { formatDistanceToNow } from 'date-fns';

interface PostCardProps {
  post: Post;
  onUpdate?: () => void;
}

export const PostCard = ({ post, onUpdate }: PostCardProps) => {
  const { user } = useAuth();
  const [isLiked, setIsLiked] = useState(post.likes.includes(user?.id || ''));
  const [likesCount, setLikesCount] = useState(post.likes.length);
  const [isAnimating, setIsAnimating] = useState(false);

  const postUser = getUserById(post.userId);

  const handleLike = () => {
    if (!user) return;

    const posts = getPostsFromStorage();
    const postIndex = posts.findIndex(p => p.id === post.id);
    
    if (postIndex !== -1) {
      if (isLiked) {
        posts[postIndex].likes = posts[postIndex].likes.filter(id => id !== user.id);
        setLikesCount(prev => prev - 1);
      } else {
        posts[postIndex].likes.push(user.id);
        setLikesCount(prev => prev + 1);
        setIsAnimating(true);
        setTimeout(() => setIsAnimating(false), 300);
      }
      savePostsToStorage(posts);
      setIsLiked(!isLiked);
      onUpdate?.();
    }
  };

  const handleDoubleClick = () => {
    if (!isLiked) {
      handleLike();
    }
  };

  if (!postUser) return null;

  return (
    <article className="border-b border-border bg-card animate-fade-in">
      {/* Header */}
      <div className="flex items-center gap-3 p-4">
        <Link to={`/profile/${postUser.username}`}>
          <img
            src={postUser.avatar}
            alt={postUser.username}
            className="h-10 w-10 rounded-full object-cover ring-2 ring-border"
          />
        </Link>
        <div className="flex-1">
          <Link to={`/profile/${postUser.username}`} className="font-semibold hover:opacity-80">
            {postUser.username}
          </Link>
        </div>
      </div>

      {/* Image */}
      <div 
        className="relative aspect-square cursor-pointer"
        onDoubleClick={handleDoubleClick}
      >
        <img
          src={post.imageUrl}
          alt={post.caption}
          className="h-full w-full object-cover"
        />
        {isAnimating && (
          <div className="absolute inset-0 flex items-center justify-center">
            <Heart className="h-24 w-24 fill-primary text-primary animate-heart-pop" />
          </div>
        )}
      </div>

      {/* Actions */}
      <div className="p-4">
        <div className="flex items-center gap-4">
          <Button
            variant="ghost"
            size="icon"
            onClick={handleLike}
            className="h-9 w-9 -ml-2"
          >
            <Heart
              className={cn(
                'h-6 w-6 transition-all',
                isLiked && 'fill-destructive text-destructive',
                isAnimating && 'animate-heart-pop'
              )}
            />
          </Button>
          <Link to={`/post/${post.id}`}>
            <Button variant="ghost" size="icon" className="h-9 w-9">
              <MessageCircle className="h-6 w-6" />
            </Button>
          </Link>
          <Button variant="ghost" size="icon" className="h-9 w-9">
            <Send className="h-6 w-6" />
          </Button>
          <Button variant="ghost" size="icon" className="h-9 w-9 ml-auto">
            <Bookmark className="h-6 w-6" />
          </Button>
        </div>

        {/* Likes */}
        <p className="mt-2 font-semibold">
          {likesCount} {likesCount === 1 ? 'like' : 'likes'}
        </p>

        {/* Caption */}
        <p className="mt-1">
          <Link to={`/profile/${postUser.username}`} className="font-semibold mr-2">
            {postUser.username}
          </Link>
          {post.caption}
        </p>

        {/* Comments Preview */}
        {post.comments.length > 0 && (
          <Link
            to={`/post/${post.id}`}
            className="mt-2 block text-muted-foreground hover:opacity-80"
          >
            View all {post.comments.length} comments
          </Link>
        )}

        {/* Timestamp */}
        <p className="mt-2 text-xs text-muted-foreground uppercase">
          {formatDistanceToNow(new Date(post.createdAt), { addSuffix: true })}
        </p>
      </div>
    </article>
  );
};
