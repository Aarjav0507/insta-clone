import { ReactNode } from 'react';
import { Navbar } from './Navbar';
import { useAuth } from '@/context/AuthContext';

interface LayoutProps {
  children: ReactNode;
}

export const Layout = ({ children }: LayoutProps) => {
  const { isAuthenticated } = useAuth();

  return (
    <div className="min-h-screen bg-background">
      <Navbar />
      <main className={isAuthenticated ? 'pt-16' : ''}>
        {children}
      </main>
    </div>
  );
};
