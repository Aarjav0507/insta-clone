import React, { createContext, useContext, useState, useEffect, ReactNode } from 'react';
import { User, AuthState } from '@/types';
import { mockUsers } from '@/data/mockData';

interface AuthContextType extends AuthState {
  login: (email: string, password: string) => Promise<boolean>;
  signup: (username: string, email: string, password: string) => Promise<boolean>;
  logout: () => void;
  updateUser: (user: User) => void;
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

export const AuthProvider: React.FC<{ children: ReactNode }> = ({ children }) => {
  const [authState, setAuthState] = useState<AuthState>({
    user: null,
    token: null,
    isAuthenticated: false,
  });

  useEffect(() => {
    const storedAuth = localStorage.getItem('insta_auth');
    if (storedAuth) {
      const parsed = JSON.parse(storedAuth);
      setAuthState(parsed);
    }
  }, []);

  const login = async (email: string, password: string): Promise<boolean> => {
    // Simulate API call
    await new Promise(resolve => setTimeout(resolve, 500));
    
    const user = mockUsers.find(u => u.email === email);
    if (user) {
      const token = `token_${Date.now()}`;
      const newState = { user, token, isAuthenticated: true };
      setAuthState(newState);
      localStorage.setItem('insta_auth', JSON.stringify(newState));
      return true;
    }
    return false;
  };

  const signup = async (username: string, email: string, password: string): Promise<boolean> => {
    // Simulate API call
    await new Promise(resolve => setTimeout(resolve, 500));
    
    const existingUser = mockUsers.find(u => u.email === email || u.username === username);
    if (existingUser) {
      return false;
    }

    const newUser: User = {
      id: `user_${Date.now()}`,
      username,
      email,
      avatar: `https://api.dicebear.com/7.x/avataaars/svg?seed=${username}`,
      bio: '',
      followers: [],
      following: [],
      createdAt: new Date().toISOString(),
    };

    mockUsers.push(newUser);
    const token = `token_${Date.now()}`;
    const newState = { user: newUser, token, isAuthenticated: true };
    setAuthState(newState);
    localStorage.setItem('insta_auth', JSON.stringify(newState));
    return true;
  };

  const logout = () => {
    setAuthState({ user: null, token: null, isAuthenticated: false });
    localStorage.removeItem('insta_auth');
  };

  const updateUser = (user: User) => {
    const newState = { ...authState, user };
    setAuthState(newState);
    localStorage.setItem('insta_auth', JSON.stringify(newState));
  };

  return (
    <AuthContext.Provider value={{ ...authState, login, signup, logout, updateUser }}>
      {children}
    </AuthContext.Provider>
  );
};

export const useAuth = () => {
  const context = useContext(AuthContext);
  if (!context) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
};
