import { User, Post } from '@/types';

export const mockUsers: User[] = [
  {
    id: 'user_1',
    username: 'alex_adventures',
    email: 'alex@example.com',
    avatar: 'https://api.dicebear.com/7.x/avataaars/svg?seed=alex',
    bio: '📷 Travel photographer | 🌍 Exploring the world one shot at a time',
    followers: ['user_2', 'user_3'],
    following: ['user_2'],
    createdAt: '2024-01-01T00:00:00Z',
  },
  {
    id: 'user_2',
    username: 'sarah_creates',
    email: 'sarah@example.com',
    avatar: 'https://api.dicebear.com/7.x/avataaars/svg?seed=sarah',
    bio: '🎨 Digital artist | ✨ Creating magic with pixels',
    followers: ['user_1'],
    following: ['user_1', 'user_3'],
    createdAt: '2024-01-02T00:00:00Z',
  },
  {
    id: 'user_3',
    username: 'mike_fitness',
    email: 'mike@example.com',
    avatar: 'https://api.dicebear.com/7.x/avataaars/svg?seed=mike',
    bio: '💪 Fitness coach | 🏋️ Transform your life',
    followers: ['user_2'],
    following: [],
    createdAt: '2024-01-03T00:00:00Z',
  },
];

export const mockPosts: Post[] = [
  {
    id: 'post_1',
    userId: 'user_1',
    imageUrl: 'https://images.unsplash.com/photo-1506905925346-21bda4d32df4?w=800&h=800&fit=crop',
    caption: 'Mountain sunrise vibes 🏔️ Nothing beats waking up to this view! #travel #mountains #sunrise',
    likes: ['user_2', 'user_3'],
    comments: [
      {
        id: 'comment_1',
        userId: 'user_2',
        postId: 'post_1',
        text: 'This is absolutely stunning! 😍',
        createdAt: '2024-12-10T10:00:00Z',
      },
    ],
    createdAt: '2024-12-10T08:00:00Z',
  },
  {
    id: 'post_2',
    userId: 'user_2',
    imageUrl: 'https://images.unsplash.com/photo-1579783902614-a3fb3927b6a5?w=800&h=800&fit=crop',
    caption: 'New digital artwork complete! 🎨 Spent 20 hours on this piece. What do you think?',
    likes: ['user_1'],
    comments: [
      {
        id: 'comment_2',
        userId: 'user_1',
        postId: 'post_2',
        text: 'Incredible work! The colors are amazing 🔥',
        createdAt: '2024-12-11T14:30:00Z',
      },
      {
        id: 'comment_3',
        userId: 'user_3',
        postId: 'post_2',
        text: 'You are so talented!',
        createdAt: '2024-12-11T15:00:00Z',
      },
    ],
    createdAt: '2024-12-11T12:00:00Z',
  },
  {
    id: 'post_3',
    userId: 'user_3',
    imageUrl: 'https://images.unsplash.com/photo-1517836357463-d25dfeac3438?w=800&h=800&fit=crop',
    caption: 'Morning workout done ✅ No excuses, just results! 💪 #fitness #motivation #gym',
    likes: [],
    comments: [],
    createdAt: '2024-12-12T06:00:00Z',
  },
  {
    id: 'post_4',
    userId: 'user_1',
    imageUrl: 'https://images.unsplash.com/photo-1507525428034-b723cf961d3e?w=800&h=800&fit=crop',
    caption: 'Beach days are the best days 🏖️ #beach #summer #paradise',
    likes: ['user_2'],
    comments: [],
    createdAt: '2024-12-13T16:00:00Z',
  },
];

export const getPostsFromStorage = (): Post[] => {
  const stored = localStorage.getItem('insta_posts');
  if (stored) {
    return JSON.parse(stored);
  }
  localStorage.setItem('insta_posts', JSON.stringify(mockPosts));
  return mockPosts;
};

export const savePostsToStorage = (posts: Post[]) => {
  localStorage.setItem('insta_posts', JSON.stringify(posts));
};

export const getUserById = (id: string): User | undefined => {
  return mockUsers.find(u => u.id === id);
};

export const getUserByUsername = (username: string): User | undefined => {
  return mockUsers.find(u => u.username === username);
};
