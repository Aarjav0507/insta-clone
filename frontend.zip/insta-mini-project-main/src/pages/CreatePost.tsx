import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { ImagePlus, ArrowLeft } from 'lucide-react';
import { useAuth } from '@/context/AuthContext';
import { getPostsFromStorage, savePostsToStorage } from '@/data/mockData';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { toast } from 'sonner';

export const CreatePost = () => {
  const [imageUrl, setImageUrl] = useState('');
  const [caption, setCaption] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const { user } = useAuth();
  const navigate = useNavigate();

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!user) return;

    if (!imageUrl.trim()) {
      toast.error('Please enter an image URL');
      return;
    }

    setIsLoading(true);

    try {
      const posts = getPostsFromStorage();
      const newPost = {
        id: `post_${Date.now()}`,
        userId: user.id,
        imageUrl: imageUrl.trim(),
        caption: caption.trim(),
        likes: [],
        comments: [],
        createdAt: new Date().toISOString(),
      };

      posts.unshift(newPost);
      savePostsToStorage(posts);

      toast.success('Post created successfully!');
      navigate('/');
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="mx-auto max-w-lg p-4">
      {/* Header */}
      <div className="mb-6 flex items-center gap-4">
        <Button variant="ghost" size="icon" onClick={() => navigate(-1)}>
          <ArrowLeft className="h-5 w-5" />
        </Button>
        <h1 className="text-xl font-semibold">Create Post</h1>
      </div>

      <form onSubmit={handleSubmit} className="space-y-6 animate-fade-in">
        {/* Image Preview */}
        <div className="relative aspect-square rounded-xl border-2 border-dashed border-border bg-secondary/50 flex items-center justify-center overflow-hidden">
          {imageUrl ? (
            <img
              src={imageUrl}
              alt="Preview"
              className="h-full w-full object-cover"
              onError={() => toast.error('Invalid image URL')}
            />
          ) : (
            <div className="text-center p-8">
              <ImagePlus className="mx-auto h-12 w-12 text-muted-foreground mb-4" />
              <p className="text-muted-foreground">Enter an image URL below</p>
            </div>
          )}
        </div>

        {/* Image URL Input */}
        <div className="space-y-2">
          <label className="text-sm font-medium">Image URL</label>
          <Input
            type="url"
            placeholder="https://example.com/image.jpg"
            value={imageUrl}
            onChange={(e) => setImageUrl(e.target.value)}
            required
          />
          <p className="text-xs text-muted-foreground">
            Tip: Use Unsplash for free images (e.g., https://images.unsplash.com/photo-...)
          </p>
        </div>

        {/* Caption */}
        <div className="space-y-2">
          <label className="text-sm font-medium">Caption</label>
          <Textarea
            placeholder="Write a caption..."
            value={caption}
            onChange={(e) => setCaption(e.target.value)}
            rows={4}
            className="resize-none"
          />
        </div>

        {/* Submit */}
        <Button
          type="submit"
          variant="gradient"
          className="w-full"
          disabled={isLoading}
        >
          {isLoading ? 'Sharing...' : 'Share'}
        </Button>
      </form>
    </div>
  );
};

export default CreatePost;
