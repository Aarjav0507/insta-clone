import { useState, useEffect } from 'react';
import { useParams, Link, useNavigate } from 'react-router-dom';
import { Heart, ArrowLeft, Send } from 'lucide-react';
import { useAuth } from '@/context/AuthContext';
import { getPostsFromStorage, savePostsToStorage, getUserById } from '@/data/mockData';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Post, Comment } from '@/types';
import { formatDistanceToNow } from 'date-fns';
import { cn } from '@/lib/utils';
import { toast } from 'sonner';

export const PostDetail = () => {
  const { id } = useParams<{ id: string }>();
  const { user } = useAuth();
  const navigate = useNavigate();
  const [post, setPost] = useState<Post | null>(null);
  const [comment, setComment] = useState('');
  const [isLiked, setIsLiked] = useState(false);

  const loadPost = () => {
    const posts = getPostsFromStorage();
    const foundPost = posts.find(p => p.id === id);
    if (foundPost) {
      setPost(foundPost);
      setIsLiked(foundPost.likes.includes(user?.id || ''));
    }
  };

  useEffect(() => {
    loadPost();
  }, [id, user]);

  const handleLike = () => {
    if (!user || !post) return;

    const posts = getPostsFromStorage();
    const postIndex = posts.findIndex(p => p.id === post.id);

    if (postIndex !== -1) {
      if (isLiked) {
        posts[postIndex].likes = posts[postIndex].likes.filter(id => id !== user.id);
      } else {
        posts[postIndex].likes.push(user.id);
      }
      savePostsToStorage(posts);
      setIsLiked(!isLiked);
      loadPost();
    }
  };

  const handleComment = (e: React.FormEvent) => {
    e.preventDefault();
    if (!user || !post || !comment.trim()) return;

    const posts = getPostsFromStorage();
    const postIndex = posts.findIndex(p => p.id === post.id);

    if (postIndex !== -1) {
      const newComment: Comment = {
        id: `comment_${Date.now()}`,
        userId: user.id,
        postId: post.id,
        text: comment.trim(),
        createdAt: new Date().toISOString(),
      };

      posts[postIndex].comments.push(newComment);
      savePostsToStorage(posts);
      setComment('');
      loadPost();
      toast.success('Comment added!');
    }
  };

  if (!post) {
    return (
      <div className="flex items-center justify-center py-20">
        <p className="text-muted-foreground">Post not found</p>
      </div>
    );
  }

  const postUser = getUserById(post.userId);

  return (
    <div className="mx-auto max-w-lg p-4 animate-fade-in">
      {/* Header */}
      <div className="mb-4 flex items-center gap-4">
        <Button variant="ghost" size="icon" onClick={() => navigate(-1)}>
          <ArrowLeft className="h-5 w-5" />
        </Button>
        <h1 className="text-xl font-semibold">Post</h1>
      </div>

      {/* Post */}
      <div className="rounded-xl border border-border bg-card overflow-hidden shadow-card">
        {/* User */}
        {postUser && (
          <div className="flex items-center gap-3 p-4 border-b border-border">
            <Link to={`/profile/${postUser.username}`}>
              <img
                src={postUser.avatar}
                alt={postUser.username}
                className="h-10 w-10 rounded-full object-cover ring-2 ring-border"
              />
            </Link>
            <Link to={`/profile/${postUser.username}`} className="font-semibold hover:opacity-80">
              {postUser.username}
            </Link>
          </div>
        )}

        {/* Image */}
        <img
          src={post.imageUrl}
          alt={post.caption}
          className="w-full aspect-square object-cover"
        />

        {/* Actions */}
        <div className="p-4">
          <Button
            variant="ghost"
            size="icon"
            onClick={handleLike}
            className="h-9 w-9 -ml-2"
          >
            <Heart
              className={cn(
                'h-6 w-6 transition-all',
                isLiked && 'fill-destructive text-destructive'
              )}
            />
          </Button>

          <p className="mt-2 font-semibold">
            {post.likes.length} {post.likes.length === 1 ? 'like' : 'likes'}
          </p>

          {postUser && (
            <p className="mt-2">
              <Link to={`/profile/${postUser.username}`} className="font-semibold mr-2">
                {postUser.username}
              </Link>
              {post.caption}
            </p>
          )}

          <p className="mt-2 text-xs text-muted-foreground uppercase">
            {formatDistanceToNow(new Date(post.createdAt), { addSuffix: true })}
          </p>
        </div>

        {/* Comments */}
        <div className="border-t border-border">
          {post.comments.length > 0 && (
            <div className="max-h-64 overflow-y-auto p-4 space-y-4">
              {post.comments.map((c) => {
                const commentUser = getUserById(c.userId);
                if (!commentUser) return null;
                return (
                  <div key={c.id} className="flex gap-3">
                    <Link to={`/profile/${commentUser.username}`}>
                      <img
                        src={commentUser.avatar}
                        alt={commentUser.username}
                        className="h-8 w-8 rounded-full object-cover"
                      />
                    </Link>
                    <div className="flex-1">
                      <p>
                        <Link to={`/profile/${commentUser.username}`} className="font-semibold mr-2 hover:opacity-80">
                          {commentUser.username}
                        </Link>
                        {c.text}
                      </p>
                      <p className="text-xs text-muted-foreground mt-1">
                        {formatDistanceToNow(new Date(c.createdAt), { addSuffix: true })}
                      </p>
                    </div>
                  </div>
                );
              })}
            </div>
          )}

          {/* Add Comment */}
          <form onSubmit={handleComment} className="flex items-center gap-2 p-4 border-t border-border">
            <Input
              placeholder="Add a comment..."
              value={comment}
              onChange={(e) => setComment(e.target.value)}
              className="flex-1"
            />
            <Button type="submit" variant="ghost" size="icon" disabled={!comment.trim()}>
              <Send className="h-5 w-5" />
            </Button>
          </form>
        </div>
      </div>
    </div>
  );
};

export default PostDetail;
