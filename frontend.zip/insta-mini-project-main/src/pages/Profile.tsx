import { useState, useEffect } from 'react';
import { useParams, Link } from 'react-router-dom';
import { Grid, Settings } from 'lucide-react';
import { useAuth } from '@/context/AuthContext';
import { getUserByUsername, getPostsFromStorage, mockUsers } from '@/data/mockData';
import { Button } from '@/components/ui/button';
import { User, Post } from '@/types';

export const Profile = () => {
  const { username } = useParams<{ username: string }>();
  const { user: currentUser, updateUser } = useAuth();
  const [profileUser, setProfileUser] = useState<User | null>(null);
  const [userPosts, setUserPosts] = useState<Post[]>([]);
  const [isFollowing, setIsFollowing] = useState(false);

  useEffect(() => {
    if (username) {
      const foundUser = getUserByUsername(username);
      if (foundUser) {
        setProfileUser(foundUser);
        setIsFollowing(currentUser?.following.includes(foundUser.id) || false);

        const posts = getPostsFromStorage();
        const filtered = posts.filter(p => p.userId === foundUser.id);
        filtered.sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime());
        setUserPosts(filtered);
      }
    }
  }, [username, currentUser]);

  const handleFollow = () => {
    if (!currentUser || !profileUser) return;

    const updatedFollowing = isFollowing
      ? currentUser.following.filter(id => id !== profileUser.id)
      : [...currentUser.following, profileUser.id];

    const updatedUser = { ...currentUser, following: updatedFollowing };
    updateUser(updatedUser);

    // Update profile user's followers
    const profileIndex = mockUsers.findIndex(u => u.id === profileUser.id);
    if (profileIndex !== -1) {
      if (isFollowing) {
        mockUsers[profileIndex].followers = mockUsers[profileIndex].followers.filter(id => id !== currentUser.id);
      } else {
        mockUsers[profileIndex].followers.push(currentUser.id);
      }
      setProfileUser({ ...mockUsers[profileIndex] });
    }

    setIsFollowing(!isFollowing);
  };

  if (!profileUser) {
    return (
      <div className="flex items-center justify-center py-20">
        <p className="text-muted-foreground">User not found</p>
      </div>
    );
  }

  const isOwnProfile = currentUser?.id === profileUser.id;

  return (
    <div className="mx-auto max-w-3xl p-4 animate-fade-in">
      {/* Profile Header */}
      <div className="flex flex-col sm:flex-row items-center gap-6 sm:gap-12 mb-8">
        <img
          src={profileUser.avatar}
          alt={profileUser.username}
          className="h-24 w-24 sm:h-36 sm:w-36 rounded-full object-cover ring-4 ring-border"
        />

        <div className="flex-1 text-center sm:text-left">
          <div className="flex flex-col sm:flex-row items-center gap-4 mb-4">
            <h1 className="text-xl font-semibold">{profileUser.username}</h1>
            {isOwnProfile ? (
              <Button variant="secondary" size="sm" className="gap-2">
                <Settings className="h-4 w-4" />
                Edit Profile
              </Button>
            ) : (
              <Button
                variant={isFollowing ? 'secondary' : 'gradient'}
                size="sm"
                onClick={handleFollow}
              >
                {isFollowing ? 'Following' : 'Follow'}
              </Button>
            )}
          </div>

          {/* Stats */}
          <div className="flex justify-center sm:justify-start gap-8 mb-4">
            <div className="text-center">
              <p className="font-semibold">{userPosts.length}</p>
              <p className="text-sm text-muted-foreground">posts</p>
            </div>
            <div className="text-center">
              <p className="font-semibold">{profileUser.followers.length}</p>
              <p className="text-sm text-muted-foreground">followers</p>
            </div>
            <div className="text-center">
              <p className="font-semibold">{profileUser.following.length}</p>
              <p className="text-sm text-muted-foreground">following</p>
            </div>
          </div>

          {/* Bio */}
          {profileUser.bio && (
            <p className="text-sm">{profileUser.bio}</p>
          )}
        </div>
      </div>

      {/* Posts Grid */}
      <div className="border-t border-border pt-4">
        <div className="flex justify-center gap-8 mb-4">
          <button className="flex items-center gap-2 py-2 border-t-2 border-foreground -mt-[17px]">
            <Grid className="h-4 w-4" />
            <span className="text-sm font-medium uppercase">Posts</span>
          </button>
        </div>

        {userPosts.length === 0 ? (
          <div className="py-20 text-center">
            <p className="text-muted-foreground">No posts yet</p>
          </div>
        ) : (
          <div className="grid grid-cols-3 gap-1">
            {userPosts.map((post) => (
              <Link
                key={post.id}
                to={`/post/${post.id}`}
                className="aspect-square overflow-hidden group relative"
              >
                <img
                  src={post.imageUrl}
                  alt={post.caption}
                  className="h-full w-full object-cover transition-transform group-hover:scale-105"
                />
                <div className="absolute inset-0 bg-foreground/0 group-hover:bg-foreground/20 transition-colors flex items-center justify-center opacity-0 group-hover:opacity-100">
                  <span className="text-background font-semibold">
                    ❤️ {post.likes.length}
                  </span>
                </div>
              </Link>
            ))}
          </div>
        )}
      </div>
    </div>
  );
};

export default Profile;
