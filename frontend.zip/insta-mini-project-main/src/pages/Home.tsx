import { useState, useEffect } from 'react';
import { PostCard } from '@/components/posts/PostCard';
import { useAuth } from '@/context/AuthContext';
import { getPostsFromStorage } from '@/data/mockData';
import { Post } from '@/types';

export const Home = () => {
  const { user } = useAuth();
  const [posts, setPosts] = useState<Post[]>([]);

  const loadPosts = () => {
    const allPosts = getPostsFromStorage();
    // Get posts from users the current user follows + their own posts
    const feedPosts = allPosts.filter(
      post => user?.following.includes(post.userId) || post.userId === user?.id
    );
    // Sort by date (newest first)
    feedPosts.sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime());
    setPosts(feedPosts);
  };

  useEffect(() => {
    loadPosts();
  }, [user]);

  return (
    <div className="mx-auto max-w-lg pb-20">
      {posts.length === 0 ? (
        <div className="flex flex-col items-center justify-center py-20 text-center">
          <p className="text-xl font-semibold mb-2">No posts yet</p>
          <p className="text-muted-foreground">
            Follow some users to see their posts in your feed!
          </p>
        </div>
      ) : (
        <div>
          {posts.map((post) => (
            <PostCard key={post.id} post={post} onUpdate={loadPosts} />
          ))}
        </div>
      )}
    </div>
  );
};

export default Home;
