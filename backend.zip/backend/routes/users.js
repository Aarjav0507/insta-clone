const express = require("express");
const User = require("../models/User");
const auth = require("../middleware/auth");

const router = express.Router();

router.post("/follow/:id", auth, async (req, res) => {
  const user = await User.findById(req.userId);
  const target = await User.findById(req.params.id);

  user.following.push(target._id);
  target.followers.push(user._id);

  await user.save();
  await target.save();
  res.json({ msg: "Followed" });
});

router.post("/unfollow/:id", auth, async (req, res) => {
  const user = await User.findById(req.userId);
  const target = await User.findById(req.params.id);

  user.following.pull(target._id);
  target.followers.pull(user._id);

  await user.save();
  await target.save();
  res.json({ msg: "Unfollowed" });
});

module.exports = router;

