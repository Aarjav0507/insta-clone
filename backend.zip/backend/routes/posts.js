const express = require("express");
const Post = require("../models/Post");
const User = require("../models/User");
const auth = require("../middleware/auth");

const router = express.Router();

router.post("/", auth, async (req, res) => {
  const post = new Post({ user: req.userId, ...req.body });
  await post.save();
  res.json(post);
});

router.post("/like/:id", auth, async (req, res) => {
  const post = await Post.findById(req.params.id);
  const i = post.likes.indexOf(req.userId);
  i === -1 ? post.likes.push(req.userId) : post.likes.splice(i, 1);
  await post.save();
  res.json(post);
});

router.post("/comment/:id", auth, async (req, res) => {
  const post = await Post.findById(req.params.id);
  post.comments.push({ user: req.userId, text: req.body.text });
  await post.save();
  res.json(post);
});

router.get("/feed", auth, async (req, res) => {
  const user = await User.findById(req.userId);
  const posts = await Post.find({ user: { $in: user.following } })
    .populate("user", "username")
    .populate("comments.user", "username");
  res.json(posts);
});

module.exports = router;
